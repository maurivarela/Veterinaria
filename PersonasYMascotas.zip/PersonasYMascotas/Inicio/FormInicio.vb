﻿Public Class FormInicio
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LogoVeterinaria_Click(sender As Object, e As EventArgs) Handles LogoVeterinaria.Click

    End Sub


End Class
