﻿Public Class Mascota
    Dim ci As Integer
    Dim nombre As String
    Dim fechaNacimiento As String

    Public Sub crearMascota(ci, nombre, fechaNacimiento)

    End Sub

End Class
