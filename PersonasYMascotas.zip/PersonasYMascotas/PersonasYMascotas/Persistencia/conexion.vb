﻿Public Class Conexion
    Public Class Conexion
        Public Function AbrirConexion() As Npgsql.NpgsqlConnection
            Dim conexion_pg As Npgsql.NpgsqlConnection
            Try
                conexion_pg = New Npgsql.NpgsqlConnection()
                Dim cadenaDeConexion As String
                cadenaDeConexion = “server = 127.0.0.1; port = 5432; user = ‘postgres‘; password = ‘root’; database = ‘PersonasYMascotas’”

                conexion_pg.ConnectionString = cadenaDeConexion
                conexion_pg.Open()


            Catch ex As Exception
                Throw ex
            End Try

            Return conexion_pg
        End Function
    End Class

    Friend Function AbrirConexion() As Object
        Throw New NotImplementedException()
    End Function
End Class
