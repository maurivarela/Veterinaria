﻿Imports Npgsql
Public Class persistenciaPersonas

    Sub New()
    End Sub
    Dim Connection = New Npgsql.NpgsqlConnection

    Public Sub altaPersona(nuevaPersona As Persona)
        Try
            Dim classConnection = New Conexion
            Connection = classConnection.AbrirConexion

            Dim cmd As New Npgsql.NpgsqlCommand
            cmd.Connection = Connection

            Dim cadenaDeComando = "INSERT INTO Personas (ci,Nombre,direccion) VALUES (@ci_,@nombre_,@direccion_);"
            cmd.CommandText = cadenaDeComando

            cmd.Parameters.Add("@ci_", NpgsqlTypes.NpgsqlDbType.Integer).Value = nuevaPersona.Ci
            cmd.Parameters.Add("@nombre_", NpgsqlTypes.NpgsqlDbType.Varchar, 50).Value = nuevaPersona.Nombre
            cmd.Parameters.Add("@direccion_", NpgsqlTypes.NpgsqlDbType.Varchar, 150).Value = nuevaPersona.Direccion
            Dim resultado As Integer
            resultado = cmd.ExecuteNonQuery()


            If resultado = 1 Then
                Dim i As Integer
                i = 0

                'Ingresar telefonos
                While i < nuevaPersona.ListaTelefono.Count
                    cmd = New Npgsql.NpgsqlCommand()
                    cmd.Connection = Connection

                    cadenaDeComando = "INSERT INTO telefonos (ci, telefono) VALUES (@ci_,@telefono_);"
                    cmd.CommandText = cadenaDeComando

                    cmd.Parameters.Add("@ci_", NpgsqlTypes.NpgsqlDbType.Integer).Value = nuevaPersona.Ci
                    cmd.Parameters.Add("@telefono_", NpgsqlTypes.NpgsqlDbType.Integer).Value = nuevaPersona.ListaTelefono.Item(i)

                    resultado = cmd.ExecuteNonQuery()

                    i = i + 1
                End While

                'Modificar telefonos
                While i < nuevaPersona.ListaTelefono.Count
                    cmd = New Npgsql.NpgsqlCommand()
                    cmd.Connection = Connection

                    cadenaDeComando = "DELETE * FROM telefonos WHERE telefono.ci = @ci"
                    cmd.CommandText = cadenaDeComando

                    cadenaDeComando = "INSERT INTO telefonos (ci, telefono) VALUES (@ci_,@telefono_);"
                    cmd.CommandText = cadenaDeComando

                    cmd.Parameters.Add("@ci_", NpgsqlTypes.NpgsqlDbType.Integer).Value = nuevaPersona.Ci
                    cmd.Parameters.Add("@telefono_", NpgsqlTypes.NpgsqlDbType.Integer).Value = nuevaPersona.ListaTelefono.Item(i)

                    resultado = cmd.ExecuteNonQuery()

                    i = i + 1
                End While
            End If

        Catch ex As Exception
            Throw ex
        Finally
            Connection.Close()
        End Try

    End Sub

    Public Function Buscarpersona(ci As Integer) As Persona
        Dim personaNueva As Persona
        Try
            Dim ClaseSln As New Conexion
            Connection = ClaseSln.AbrirConexion
            Dim cmd As Npgsql.NpgsqlCommand
            cmd.Connection = Connection

            Dim cadenaDeComandos = "Select * FROM personas WHERE cedulaPersona = @ci"
            cmd.CommandText = cadenaDeComandos
            cmd.Parameters.Add("@ci", NpgsqlTypes.NpgsqlDbType.Integer).Value = ci

            Dim reader As Npgsql.NpgsqlDataReader = cmd.ExecuteReader


            If reader.HasRows Then
                reader.Read()

                personaNueva.Ci = Convert.ToInt32(reader(0).ToString)
                personaNueva.Nombre = reader(1).ToString
                personaNueva.Direccion = reader(2).ToString
            End If

        Catch ex As Exception
            Throw ex
        End Try

        Return personaNueva
    End Function
End Class
