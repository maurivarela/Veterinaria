﻿Public Class FormPyM

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles labelPersonas.Click

    End Sub

    Private Sub CiPersonaInput_TextChanged(sender As Object, e As EventArgs) Handles textCi.TextChanged
        Dim cedula As Integer
        cedula = textCi.Text
        Dim personaNueva As Persona
        Dim logica As logicaPersona
        personaNueva = logica.buscarPersona(cedula)
        If IsNothing(personaNueva) Then
        Else
            textNombre.Text = personaNueva.Nombre
            textDireccion.Text = personaNueva.Direccion
        End If
    End Sub


    Public Sub btnCapturarPersonas_Click(sender As Object, e As EventArgs) Handles btnCapturarPersonas.Click
        Dim ci As Integer
        Dim nombre As String
        Dim telefono As Integer
        Dim direccion As String

        ci = textCi.Text
        nombre = textNombre.Text
        telefono = textTelefono.Text
        direccion = textDireccion.Text

        labelVerResultado.Text = ci & "   |   " & nombre & "   |   " & telefono & "   |   " & direccion

        Try
            Dim newPersona As New Persona()
            newPersona.ci = ci
            newPersona.nombre = nombre
            newPersona.direccion = direccion

            Dim logica As New logicaPersona
            logica.altaPersona(newPersona)

        Catch ex As Exception

        End Try


    End Sub

    Private Sub labelVerResultado_Click(sender As Object, e As EventArgs) Handles labelVerResultado.Click


    End Sub
End Class
